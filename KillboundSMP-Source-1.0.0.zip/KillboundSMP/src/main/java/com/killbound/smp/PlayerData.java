package com.killbound.smp;

import java.util.UUID;

public final class PlayerData {
    private final UUID uuid;
    private String lastName;
    private int kills;
    private int totalKills;
    private int deaths;

    public PlayerData(UUID uuid, String lastName) {
        this.uuid = uuid;
        this.lastName = lastName;
    }

    public UUID getUuid() { return uuid; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public int getKills() { return kills; }
    public void setKills(int kills) { this.kills = Math.max(0, kills); }
    public int getTotalKills() { return totalKills; }
    public void addTotalKill() { totalKills++; }
    public int getDeaths() { return deaths; }
    public void addDeath() { deaths++; }
}
