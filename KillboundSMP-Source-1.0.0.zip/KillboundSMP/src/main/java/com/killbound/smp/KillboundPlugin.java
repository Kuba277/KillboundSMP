package com.killbound.smp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;
import org.bukkit.scoreboard.Team;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public final class KillboundPlugin extends JavaPlugin implements Listener {
    private final Map<UUID, PlayerData> players = new HashMap<>();
    private final Map<String, Long> recentKills = new ConcurrentHashMap<>();
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private int deathPenalty;
    private int maxKills;
    private long antiFarmMillis;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        loadPlayerData();
        Bukkit.getPluginManager().registerEvents(this, this);

        Objects.requireNonNull(getCommand("kills")).setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(color(msg("player-only")));
                return true;
            }
            showKills(player);
            return true;
        });
        Objects.requireNonNull(getCommand("killtop")).setExecutor((sender, command, label, args) -> {
            showTop(sender);
            return true;
        });
        Objects.requireNonNull(getCommand("killstats")).setExecutor((sender, command, label, args) -> {
            if (args.length == 0 && !(sender instanceof Player)) {
                sender.sendMessage(color(msg("player-only")));
                return true;
            }
            PlayerData data;
            if (args.length == 0) {
                data = getData((Player) sender);
            } else {
                data = findData(args[0]);
                if (data == null) {
                    sender.sendMessage(color(msg("no-player")));
                    return true;
                }
            }
            showStats(sender, data);
            return true;
        });

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                applyEffects(player);
                updateScoreboard(player);
            }
        }, 20L, 200L);

        getLogger().info("Killbound SMP enabled. Loaded " + players.size() + " player profiles.");
    }

    @Override
    public void onDisable() {
        savePlayerData();
    }

    private void loadSettings() {
        deathPenalty = Math.max(0, getConfig().getInt("progression.death-penalty", 2));
        maxKills = Math.max(1, getConfig().getInt("progression.max-kills", 22));
        antiFarmMillis = Math.max(0, getConfig().getLong("progression.anti-farm-cooldown-seconds", 60)) * 1000L;
    }

    private PlayerData getData(Player player) {
        PlayerData data = players.computeIfAbsent(player.getUniqueId(), id -> new PlayerData(id, player.getName()));
        data.setLastName(player.getName());
        return data;
    }

    private PlayerData findData(String name) {
        return players.values().stream()
                .filter(d -> d.getLastName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        getData(player);
        applyEffects(player);
        updateScoreboard(player);
        savePlayerData();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        savePlayerData();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        PlayerData victimData = getData(victim);
        victimData.addDeath();
        victimData.setKills(victimData.getKills() - deathPenalty);
        applyEffects(victim);
        updateScoreboard(victim);
        victim.sendMessage(color(msg("death")
                .replace("%player%", victim.getName())
                .replace("%kills%", String.valueOf(victimData.getKills()))
                .replace("%penalty%", String.valueOf(deathPenalty))));

        Player killer = victim.getKiller();
        if (killer != null && !killer.getUniqueId().equals(victim.getUniqueId())) {
            String key = killer.getUniqueId() + ":" + victim.getUniqueId();
            long now = System.currentTimeMillis();
            Long last = recentKills.get(key);
            if (last == null || now - last >= antiFarmMillis) {
                recentKills.put(key, now);
                PlayerData killerData = getData(killer);
                int before = killerData.getKills();
                if (before < maxKills) {
                    killerData.setKills(Math.min(maxKills, before + 1));
                    killerData.addTotalKill();
                    applyEffects(killer);
                    updateScoreboard(killer);
                    killer.sendMessage(color(msg("kill")
                            .replace("%killer%", killer.getName())
                            .replace("%victim%", victim.getName())));
                    if (before < maxKills && killerData.getKills() == maxKills) {
                        Bukkit.broadcastMessage(color(msg("max-reached").replace("%player%", killer.getName())));
                    } else if (killerData.getKills() > before) {
                        killer.sendMessage(color(msg("upgrade").replace("%kills%", String.valueOf(killerData.getKills()))));
                    }
                    sendDiscordKill(killer, victim, killerData.getKills());
                } else {
                    killer.sendMessage(color("&7You are already at the maximum kill level."));
                }
            } else {
                killer.sendMessage(color("&cNo kill point awarded: anti-farm cooldown is active for this victim."));
            }
        }
        savePlayerData();
    }

    private void applyEffects(Player player) {
        PlayerData data = getData(player);
        for (PotionEffectType type : managedEffects()) player.removePotionEffect(type);
        for (PotionEffect effect : effectsFor(data.getKills())) {
            player.addPotionEffect(new PotionEffect(effect.getType(), 1_000_000, effect.getAmplifier(), false, false, true));
        }
    }

    private Set<PotionEffectType> managedEffects() {
        return Set.of(PotionEffectType.FIRE_RESISTANCE, PotionEffectType.SPEED,
                PotionEffectType.STRENGTH, PotionEffectType.RESISTANCE, PotionEffectType.REGENERATION);
    }

    private List<PotionEffect> effectsFor(int kills) {
        List<PotionEffect> selected = new ArrayList<>();
        var tiers = getConfig().getMapList("progression.tiers");
        int bestTier = -1;
        for (int i = 0; i < tiers.size(); i++) {
            Object raw = tiers.get(i).get("kills");
            if (raw instanceof Number number && kills >= number.intValue()) bestTier = i;
        }
        if (bestTier < 0) return selected;
        Object rawEffects = tiers.get(bestTier).get("effects");
        if (!(rawEffects instanceof List<?> list)) return selected;
        for (Object raw : list) {
            if (!(raw instanceof String spec)) continue;
            String[] parts = spec.split(":");
            PotionEffectType type = potionType(parts[0]);
            int amplifier = parts.length > 1 ? parseInt(parts[1], 0) : 0;
            if (type != null) selected.add(new PotionEffect(type, 1_000_000, Math.max(0, amplifier)));
        }
        return selected;
    }

    private PotionEffectType potionType(String name) {
        return switch (name.toUpperCase(Locale.ROOT)) {
            case "FIRE_RESISTANCE" -> PotionEffectType.FIRE_RESISTANCE;
            case "SPEED" -> PotionEffectType.SPEED;
            case "STRENGTH" -> PotionEffectType.STRENGTH;
            case "RESISTANCE" -> PotionEffectType.RESISTANCE;
            case "REGENERATION" -> PotionEffectType.REGENERATION;
            default -> null;
        };
    }

    private int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (NumberFormatException ex) { return fallback; }
    }

    private void showKills(Player player) {
        PlayerData data = getData(player);
        player.sendMessage(color("&8&m------------------------------"));
        player.sendMessage(color("&c&lKILLBOUND &7| Your Progress"));
        player.sendMessage(color("&fKills: &c" + data.getKills() + "&7/" + maxKills));
        player.sendMessage(color("&fEffects: &a" + effectNames(data.getKills())));
        player.sendMessage(color("&fNext upgrade: &e" + nextUpgrade(data.getKills())));
        player.sendMessage(color("&8&m------------------------------"));
    }

    private void showTop(org.bukkit.command.CommandSender sender) {
        sender.sendMessage(color("&8&m------------------------------"));
        sender.sendMessage(color("&c&lKILLBOUND &7| Kill Leaderboard"));
        List<PlayerData> sorted = players.values().stream()
                .sorted(Comparator.comparingInt(PlayerData::getKills).reversed()
                        .thenComparing(Comparator.comparingInt(PlayerData::getTotalKills).reversed()))
                .limit(10).toList();
        if (sorted.isEmpty()) sender.sendMessage(color("&7No player data yet."));
        for (int i = 0; i < sorted.size(); i++) {
            PlayerData d = sorted.get(i);
            sender.sendMessage(color("&e#" + (i + 1) + " &f" + d.getLastName() + " &7- &c" + d.getKills() + " kills"));
        }
        sender.sendMessage(color("&8&m------------------------------"));
    }

    private void showStats(org.bukkit.command.CommandSender sender, PlayerData data) {
        sender.sendMessage(color("&8&m------------------------------"));
        sender.sendMessage(color("&c&lKILLBOUND &7| " + data.getLastName()));
        sender.sendMessage(color("&fCurrent kills: &c" + data.getKills() + "&7/" + maxKills));
        sender.sendMessage(color("&fLifetime kills: &a" + data.getTotalKills()));
        sender.sendMessage(color("&fDeaths: &c" + data.getDeaths()));
        sender.sendMessage(color("&fK/D: &e" + (data.getDeaths() == 0 ? data.getTotalKills() : String.format(Locale.US, "%.2f", (double) data.getTotalKills() / data.getDeaths()))));
        sender.sendMessage(color("&fEffects: &a" + effectNames(data.getKills())));
        sender.sendMessage(color("&8&m------------------------------"));
    }

    private void updateScoreboard(Player player) {
        if (!getConfig().getBoolean("scoreboard.enabled", true)) return;
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) return;
        Scoreboard board = manager.getNewScoreboard();
        Objective objective = board.registerNewObjective("killbound", "dummy", color(getConfig().getString("scoreboard.title", "&c&lKILLBOUND")));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        PlayerData data = getData(player);
        List<String> configured = getConfig().getStringList("scoreboard.lines");
        int score = configured.size();
        for (String raw : configured) {
            String line = raw.replace("%kills%", String.valueOf(data.getKills()))
                    .replace("%next_upgrade%", nextUpgrade(data.getKills()))
                    .replace("%effects%", effectNames(data.getKills()));
            if (line.length() > 40) line = line.substring(0, 40);
            String unique = color(line) + ChatColor.values()[score % ChatColor.values().length];
            objective.getScore(unique).setScore(score--);
        }
        player.setScoreboard(board);
    }

    private String effectNames(int kills) {
        List<String> names = new ArrayList<>();
        for (PotionEffect effect : effectsFor(kills)) {
            String name = effect.getType().getKey().getKey().replace('_', ' ').toLowerCase(Locale.ROOT);
            names.add(name + (effect.getAmplifier() > 0 ? " " + (effect.getAmplifier() + 1) : ""));
        }
        return names.isEmpty() ? "None" : String.join(", ", names);
    }

    private String nextUpgrade(int kills) {
        for (Map<?, ?> tier : getConfig().getMapList("progression.tiers")) {
            Object raw = tier.get("kills");
            if (raw instanceof Number number && number.intValue() > kills) {
                return number.intValue() + " kills";
            }
        }
        return "MAX LEVEL";
    }

    private String msg(String path) {
        return getConfig().getString("messages." + path, "&cMissing message: " + path);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    private void sendDiscordKill(Player killer, Player victim, int currentKills) {
        if (!getConfig().getBoolean("discord.enabled", false)) return;
        String url = getConfig().getString("discord.webhook-url", "");
        if (url == null || url.isBlank() || !url.startsWith("https://")) return;

        String username = getConfig().getString("discord.username", "Killbound SMP");
        String avatar = getConfig().getString("discord.avatar-url", "");
        String content = "{\"username\":\"" + json(username) + "\","
                + "\"content\":\"⚔️ **" + json(killer.getName()) + "** eliminated **" + json(victim.getName())
                + "** (+1 Kill) | Current kills: **" + currentKills + "** | " + json(Instant.now().toString()) + "\"";
        if (avatar != null && !avatar.isBlank() && avatar.startsWith("https://")) {
            content += ",\"avatar_url\":\"" + json(avatar) + "\"";
        }
        content += "}";
        HttpRequest request;
        try {
            request = HttpRequest.newBuilder(URI.create(url))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(content))
                    .build();
        } catch (IllegalArgumentException ex) {
            getLogger().warning("Discord webhook URL is invalid.");
            return;
        }
        httpClient.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .thenAccept(response -> {
                    if (response.statusCode() < 200 || response.statusCode() >= 300) {
                        getLogger().warning("Discord webhook returned HTTP " + response.statusCode());
                    }
                })
                .exceptionally(error -> {
                    getLogger().warning("Could not send Discord kill log: " + error.getMessage());
                    return null;
                });
    }

    private String json(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r");
    }

    private void loadPlayerData() {
        var section = getConfig().getConfigurationSection("player-data");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                String path = "player-data." + key;
                PlayerData data = new PlayerData(uuid, getConfig().getString(path + ".name", "Unknown"));
                data.setKills(getConfig().getInt(path + ".kills", 0));
                int total = getConfig().getInt(path + ".total-kills", 0);
                for (int i = 0; i < total; i++) data.addTotalKill();
                int deaths = getConfig().getInt(path + ".deaths", 0);
                for (int i = 0; i < deaths; i++) data.addDeath();
                players.put(uuid, data);
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("Skipping invalid player UUID in data.");
            }
        }
    }

    private void savePlayerData() {
        for (PlayerData data : players.values()) {
            String path = "player-data." + data.getUuid();
            getConfig().set(path + ".name", data.getLastName());
            getConfig().set(path + ".kills", data.getKills());
            getConfig().set(path + ".total-kills", data.getTotalKills());
            getConfig().set(path + ".deaths", data.getDeaths());
        }
        saveConfig();
    }
}
