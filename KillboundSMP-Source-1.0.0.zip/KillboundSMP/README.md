# Killbound SMP 1.0.0

Paper plugin project for Minecraft 1.21.11.

## Requirements
- Paper 1.21.11
- Java 21
- Maven 3.9+

## Build
From this folder run:

```bash
mvn clean package
```

The plugin JAR will be created at:

`target/KillboundSMP-1.0.0.jar`

Copy that JAR into your server's `plugins/` folder and restart the server.

## Commands
- `/kills`
- `/killtop`
- `/killstats [player]`

## Discord webhook
1. Create a webhook in the Discord channel's Integrations settings.
2. Stop the Minecraft server.
3. Open `plugins/KillboundSMP/config.yml`.
4. Set `discord.enabled: true`.
5. Paste the URL into `discord.webhook-url`.
6. Restart the server.

Keep the webhook URL private. Anyone with the URL can post messages to that channel.

## Notes
- Current kills are capped at 22.
- Every player death subtracts 2 current kills (minimum 0).
- The tier effects are cumulative as configured in `progression.tiers`.
- A killer cannot farm the same victim repeatedly inside the configured anti-farm cooldown.
- Player profiles are saved in the plugin config file.
- Discord notifications are sent asynchronously, so webhook requests do not block the server thread.

## Important testing note
This is a first implementation. Test it on a separate staging server before using it on a public SMP. In particular, review the scoreboard appearance with your chosen server resource pack/plugins.
